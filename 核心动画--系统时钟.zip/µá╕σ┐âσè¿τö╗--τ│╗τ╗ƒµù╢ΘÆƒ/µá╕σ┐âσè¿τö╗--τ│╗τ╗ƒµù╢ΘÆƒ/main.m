//
//  main.m
//  核心动画--系统时钟
//
//  Created by 周松岩 on 2016/10/29.
//  Copyright © 2016年 SoYoung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
