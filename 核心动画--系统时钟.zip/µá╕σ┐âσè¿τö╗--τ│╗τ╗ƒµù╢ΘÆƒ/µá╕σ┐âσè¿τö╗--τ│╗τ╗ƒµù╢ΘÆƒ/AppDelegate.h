//
//  AppDelegate.h
//  核心动画--系统时钟
//
//  Created by 周松岩 on 2016/10/29.
//  Copyright © 2016年 SoYoung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

